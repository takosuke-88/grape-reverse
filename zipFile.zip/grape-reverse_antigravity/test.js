import { reverseGrape } from "./dist/index.js";

console.log(
  reverseGrape({ coins: 15000, bonus: 6720, cherry: 267 })
);
