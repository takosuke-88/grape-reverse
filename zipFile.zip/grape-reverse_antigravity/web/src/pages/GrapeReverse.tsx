// C:\Users\moonc\Documents\grape-reverse\web\src\pages\GrapeReverse.tsx
import React, { useMemo, useState, useEffect } from 'react'

/** 共通定数 */
const CONSTS = {
  REPLAY_RATE: 1 / 7.298,
  REPLAY_PAYOUT: 3,
  CHERRY_PAYOUT: 2,
  GRAPE_PAYOUT: 8,
  REG_PAYOUT: 96,
  CHERRY_GET_FREE: 2 / 3,
  CHERRY_GET_AIM: 1.0,
}

/** 機種型 */
type MachineKey =
  | 'aim_ex6'
  | 'myj5'
  | 'funky2'
  | 'gogo3'
  | 'girls_ss'
  | 'ultra_miracle'
  | 'mister'
  | 'happy_v3'

type CherryBySetting = { 1: number; 2: number; 3: number; 4: number; 5: number; 6: number }
type MachinePreset = {
  label: string
  big: number
  reg: number
  cherryRateBySetting: CherryBySetting
}

/** 機種データ（内部計算は設定3の非重複チェリー確率を使用） */
const MACHINES: Record<MachineKey, MachinePreset> = {
  // SアイムEX／ネオアイムジャグラーEX（6号機）
  aim_ex6: {
    label: 'SアイムEX／ネオアイムジャグラーEX（6号機）',
    big: 252,
    reg: CONSTS.REG_PAYOUT,
    cherryRateBySetting: {
      1: 1 / 35.62,
      2: 1 / 35.62,
      3: 1 / 35.62,
      4: 1 / 35.62,
      5: 1 / 35.62,
      6: 1 / 35.62,
    },
  },

  // マイジャグラーV
  myj5: {
    label: 'マイジャグラーV',
    big: 240,
    reg: CONSTS.REG_PAYOUT,
    cherryRateBySetting: {
      1: 1 / 38.1,
      2: 1 / 38.1,
      3: 1 / 36.82,
      4: 1 / 35.62,
      5: 1 / 35.62,
      6: 1 / 35.62,
    },
  },

  // ファンキージャグラー2
  funky2: {
    label: 'ファンキージャグラー2',
    big: 240,
    reg: CONSTS.REG_PAYOUT,
    cherryRateBySetting: {
      1: 1 / 35.62,
      2: 1 / 35.62,
      3: 1 / 35.62,
      4: 1 / 35.62,
      5: 1 / 35.62,
      6: 1 / 35.62,
    },
  },

  // ゴーゴージャグラー3
  gogo3: {
    label: 'ゴーゴージャグラー3',
    big: 240,
    reg: CONSTS.REG_PAYOUT,
    cherryRateBySetting: {
      1: 1 / 33.56,
      2: 1 / 33.47,
      3: 1 / 33.32,
      4: 1 / 33.15,
      5: 1 / 33.1,
      6: 1 / 32.97,
    },
  },

  // ジャグラーガールズSS
  girls_ss: {
    label: 'ジャグラーガールズSS',
    big: 240,
    reg: CONSTS.REG_PAYOUT,
    cherryRateBySetting: {
      1: 1 / 33.56,
      2: 1 / 33.47,
      3: 1 / 33.21,
      4: 1 / 33.15,
      5: 1 / 33.1,
      6: 1 / 32.97,
    },
  },

  // ウルトラミラクルジャグラー
  ultra_miracle: {
    label: 'ウルトラミラクルジャグラー',
    big: 240,
    reg: CONSTS.REG_PAYOUT,
    cherryRateBySetting: {
      1: 1 / 35.1,
      2: 1 / 35.0,
      3: 1 / 34.8,
      4: 1 / 34.7,
      5: 1 / 33.5,
      6: 1 / 33.0,
    },
  },

  // ミスタージャグラー
  mister: {
    label: 'ミスタージャグラー',
    big: 240,
    reg: CONSTS.REG_PAYOUT,
    cherryRateBySetting: {
      1: 1 / 37.24,
      2: 1 / 37.24,
      3: 1 / 37.24,
      4: 1 / 37.24,
      5: 1 / 37.24,
      6: 1 / 37.24,
    },
  },

  // ハッピージャグラーVⅢ（ブイスリー）
  happy_v3: {
    label: 'ハッピージャグラーVⅢ（ブイスリー）',
    big: 240,
    reg: CONSTS.REG_PAYOUT,
    cherryRateBySetting: {
      1: 1 / 62.24,
      2: 1 / 62.47,
      3: 1 / 62.95,
      4: 1 / 64.0,
      5: 1 / 64.57,
      6: 1 / 65.34,
    },
  },
}

/** 参考：機種ごとの設定別ぶどう確率（分母） */
type GrapeRates = { 1: number; 2: number; 3: number; 4: number; 5: number; 6: number }
const GRAPE_RATE_TABLE: Partial<Record<MachineKey, GrapeRates>> = {
  aim_ex6: { 1: 6.02, 2: 6.02, 3: 6.02, 4: 6.02, 5: 6.02, 6: 5.78 },
  myj5: { 1: 5.88, 2: 5.85, 3: 5.79, 4: 5.78, 5: 5.76, 6: 5.66 },
  funky2: { 1: 5.94, 2: 5.92, 3: 5.88, 4: 5.83, 5: 5.76, 6: 5.67 },
  gogo3: { 1: 6.25, 2: 6.2, 3: 6.15, 4: 6.07, 5: 6.0, 6: 5.92 },
  girls_ss: { 1: 5.98, 2: 5.98, 3: 5.98, 4: 5.98, 5: 5.88, 6: 5.83 },
  ultra_miracle: { 1: 5.93, 2: 5.93, 3: 5.93, 4: 5.93, 5: 5.87, 6: 5.81 },
  mister: { 1: 6.29, 2: 6.22, 3: 6.15, 4: 6.09, 5: 6.02, 6: 5.96 },
  happy_v3: { 1: 6.04, 2: 6.03, 3: 6.0, 4: 5.86, 5: 5.81, 6: 5.79 },
}

/** 設定番号の型（1〜6固定） */
type Setting = 1 | 2 | 3 | 4 | 5 | 6

/** 機種ごとのボーナス確率テーブル（分母） */
const BONUS_RATE_TABLE: Record<
  MachineKey,
  Record<Setting, { big: number; reg: number; combined: number }>
> = {
  // SアイムEX／ネオアイムジャグラーEX（6号機）
  aim_ex6: {
    1: { big: 273.1, reg: 439.8, combined: 168.5 },
    2: { big: 269.7, reg: 399.6, combined: 161.0 },
    3: { big: 269.7, reg: 331.0, combined: 148.6 },
    4: { big: 259.0, reg: 315.1, combined: 142.2 },
    5: { big: 259.0, reg: 255.0, combined: 128.5 },
    6: { big: 255.0, reg: 255.0, combined: 127.5 },
  },

  // マイジャグラーV
  myj5: {
    1: { big: 267.5, reg: 425.6, combined: 164.3 },
    2: { big: 261.1, reg: 402.1, combined: 158.3 },
    3: { big: 256.0, reg: 350.5, combined: 147.9 },
    4: { big: 242.7, reg: 322.8, combined: 138.6 },
    5: { big: 233.2, reg: 297.9, combined: 130.8 },
    6: { big: 216.3, reg: 277.7, combined: 121.6 },
  },

  // ファンキージャグラー2
  funky2: {
    1: { big: 266.4, reg: 439.8, combined: 165.9 },
    2: { big: 259.0, reg: 407.1, combined: 158.3 },
    3: { big: 256.0, reg: 366.1, combined: 150.7 },
    4: { big: 249.2, reg: 322.8, combined: 140.6 },
    5: { big: 240.1, reg: 299.3, combined: 133.2 },
    6: { big: 219.9, reg: 262.1, combined: 119.6 },
  },

  // ゴーゴージャグラー3
  gogo3: {
    1: { big: 259.0, reg: 354.2, combined: 149.6 },
    2: { big: 258.0, reg: 332.7, combined: 145.3 },
    3: { big: 257.0, reg: 306.2, combined: 139.7 },
    4: { big: 254.0, reg: 268.6, combined: 130.5 },
    5: { big: 247.3, reg: 247.3, combined: 123.7 },
    6: { big: 234.9, reg: 234.9, combined: 117.4 },
  },

  // ジャグラーガールズSS
  girls_ss: {
    1: { big: 273.1, reg: 381.0, combined: 159.1 },
    2: { big: 270.8, reg: 350.5, combined: 152.8 },
    3: { big: 260.1, reg: 316.6, combined: 142.8 },
    4: { big: 250.1, reg: 281.3, combined: 132.4 },
    5: { big: 243.6, reg: 270.8, combined: 128.3 },
    6: { big: 226.0, reg: 252.1, combined: 119.2 },
  },

  // ウルトラミラクルジャグラー
  ultra_miracle: {
    1: { big: 273.1, reg: 409.6, combined: 163.8 },
    2: { big: 270.8, reg: 385.5, combined: 159.1 },
    3: { big: 266.4, reg: 336.1, combined: 148.6 },
    4: { big: 254.0, reg: 290.0, combined: 135.4 },
    5: { big: 240.1, reg: 268.6, combined: 126.8 },
    6: { big: 229.1, reg: 229.1, combined: 114.6 },
  },

  // ミスタージャグラー
  mister: {
    1: { big: 268.6, reg: 374.5, combined: 156.4 },
    2: { big: 267.5, reg: 354.2, combined: 152.4 },
    3: { big: 260.1, reg: 331.0, combined: 145.6 },
    4: { big: 249.2, reg: 291.3, combined: 134.3 },
    5: { big: 240.9, reg: 257.0, combined: 124.4 },
    6: { big: 237.4, reg: 237.4, combined: 118.7 },
  },

  // ハッピージャグラーVⅢ（ブイスリー）
  happy_v3: {
    1: { big: 273.1, reg: 397.2, combined: 161.8 },
    2: { big: 270.8, reg: 362.1, combined: 154.9 },
    3: { big: 263.2, reg: 332.7, combined: 146.9 },
    4: { big: 254.0, reg: 300.6, combined: 137.7 },
    5: { big: 239.2, reg: 273.1, combined: 127.5 },
    6: { big: 226.0, reg: 256.0, combined: 120.0 },
  },
}

const nf1 = new Intl.NumberFormat('ja-JP', {
  minimumFractionDigits: 1,
  maximumFractionDigits: 1,
})
const nf2 = new Intl.NumberFormat('ja-JP', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})

/** 計算結果型 */
type CalcResult =
  | { ok: true; p: number; denom: number; percent: number; grapeCount: number }
  | { ok: false; reason: string }
// ぶどう評価用の型
type GrapeConfidence = 'low' | 'mid' | 'high'

type GrapeEval = {
  nearestSetting: Setting
  nearestSettingDenom: number
  actualDenom: number
  diff: number
  diffAbs: number
  confidence: GrapeConfidence
  totalGames: number
}

export default function GrapeReverse() {
  const [machineKey, setMachineKey] = useState<MachineKey>('aim_ex6')
  const m = MACHINES[machineKey]

  const [bigCount, setBigCount] = useState('')
  const [regCount, setRegCount] = useState('')
  const [diffCoins, setDiffCoins] = useState('')
  const [totalGames, setTotalGames] = useState('')

  // localStorage自動保存・復元
  const STORAGE_KEY = 'grape-reverse-form'
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      if (saved) {
        const parsed = JSON.parse(saved)
        if (parsed.machineKey) setMachineKey(parsed.machineKey)
        if (parsed.bigCount) setBigCount(String(parsed.bigCount))
        if (parsed.regCount) setRegCount(String(parsed.regCount))
        if (parsed.diffCoins) setDiffCoins(String(parsed.diffCoins))
        if (parsed.totalGames) setTotalGames(String(parsed.totalGames))
      }
    } catch {}
  }, [])
  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ machineKey, bigCount, diffCoins, regCount, totalGames }),
      )
    } catch {}
  }, [machineKey, bigCount, regCount, diffCoins, totalGames])

  const parsed = {
    big: Number(bigCount),
    reg: Number(regCount),
    diff: Number(diffCoins),
    total: Number(totalGames),
  }

  const ready =
    Number.isFinite(parsed.big) &&
    Number.isFinite(parsed.reg) &&
    Number.isFinite(parsed.diff) &&
    Number.isFinite(parsed.total) &&
    parsed.total > 0

  /** 選択機種の逆算（上部カード） */
  const CHERRY_RATE = m.cherryRateBySetting[3]
  const compute = (cherryGetRate: number): CalcResult => {
    if (!ready) return { ok: false, reason: 'not_ready' }
    const { big, reg, diff, total } = parsed
    const invest = total * 3
    const payoutBigReg = big * m.big + reg * m.reg
    const payoutReplay = total * CONSTS.REPLAY_RATE * CONSTS.REPLAY_PAYOUT
    const payoutCherry = total * CHERRY_RATE * CONSTS.CHERRY_PAYOUT * cherryGetRate
    const payoutNonGrape = payoutBigReg + payoutReplay + payoutCherry
    const grapePayoutTotal = diff + invest - payoutNonGrape
    if (grapePayoutTotal <= 0) return { ok: false, reason: 'no_grape' }
    const grapeCount = grapePayoutTotal / CONSTS.GRAPE_PAYOUT
    if (grapeCount <= 0) return { ok: false, reason: 'grape_error' }
    const p = grapeCount / total
    const denom = total / grapeCount
    const percent = p * 100
    return { ok: true, p, denom, percent, grapeCount }
  }

  // チェリー狙い／フリー打ちの結果
  const resAim = useMemo(() => compute(CONSTS.CHERRY_GET_AIM), [parsed, ready, machineKey])
  const resFree = useMemo(() => compute(CONSTS.CHERRY_GET_FREE), [parsed, ready, machineKey])

  /** ---- 4つの確率から「最も近い設定番号」を求める ---- */
  const highlightBigSetting = useMemo(() => {
    if (!ready || parsed.big <= 0) return null
    const actualBig = parsed.total / parsed.big
    const bonus = BONUS_RATE_TABLE[machineKey]
    const table = Object.fromEntries(Object.entries(bonus).map(([s, v]) => [Number(s), v.big]))
    return findNearestSetting(actualBig, table)
  }, [ready, parsed.big, parsed.total, machineKey])

  const highlightRegSetting = useMemo(() => {
    if (!ready || parsed.reg <= 0) return null
    const actualReg = parsed.total / parsed.reg
    const bonus = BONUS_RATE_TABLE[machineKey]
    const table = Object.fromEntries(Object.entries(bonus).map(([s, v]) => [Number(s), v.reg]))
    return findNearestSetting(actualReg, table)
  }, [ready, parsed.reg, parsed.total, machineKey])

  const highlightCombinedSetting = useMemo(() => {
    if (!ready || parsed.big + parsed.reg <= 0) return null
    const actualCombined = parsed.total / (parsed.big + parsed.reg)
    const bonus = BONUS_RATE_TABLE[machineKey]
    const table = Object.fromEntries(Object.entries(bonus).map(([s, v]) => [Number(s), v.combined]))
    return findNearestSetting(actualCombined, table)
  }, [ready, parsed.big, parsed.reg, parsed.total, machineKey])

  const highlightGrapeSetting = useMemo(() => {
    if (!ready || resFree.ok === false) return null
    const actualGrape = resFree.denom
    const grape = GRAPE_RATE_TABLE[machineKey]
    if (!grape) return null
    return findNearestSetting(actualGrape, grape)
  }, [ready, resFree, machineKey])

  // ぶどう設定マッチ＋簡易評価（チェリー狙いを基準に判定）
  const grapeEval: GrapeEval | null = useMemo(() => {
    // if (!ready) return null
    if (!resAim.ok) return null

    const grapeData = GRAPE_RATE_TABLE[machineKey]
    if (!grapeData) return null

    const actualDenom = resAim.denom
    const settings: Setting[] = [1, 2, 3, 4, 5, 6]

    let best: GrapeEval | null = null

    for (const s of settings) {
      const official = grapeData[s]
      if (!official) continue
      const diff = actualDenom - official
      const diffAbs = Math.abs(diff)

      if (!best || diffAbs < best.diffAbs) {
        best = {
          nearestSetting: s,
          nearestSettingDenom: official,
          actualDenom,
          diff,
          diffAbs,
          confidence: 'low', // 一旦ここでは仮。あとで下で上書き
          totalGames: parsed.total,
        }
      }
    }

    if (!best) return null

    // 総回転数から信頼度をざっくり決める
    let confidence: GrapeConfidence = 'low'
    if (parsed.total >= 3000) {
      confidence = 'high'
    } else if (parsed.total >= 1000) {
      confidence = 'mid'
    }

    return { ...best, confidence }
  }, [ready, resAim, machineKey, parsed.total])

  return (
    <div className="min-h-[calc(100vh-4rem)] w-full bg-slate-50 px-4 py-6 sm:py-10 dark:bg-slate-950">
      <div className="mx-auto flex max-w-5xl flex-col items-center gap-6 sm:gap-8">
        {/* 上部：入力カード ＋ 結果カード */}
        <div className="w-full max-w-2xl space-y-4 rounded-2xl bg-white p-4 shadow-lg ring-1 ring-slate-200 sm:p-6 dark:bg-slate-900 dark:ring-slate-800">
          <h2 className="text-center text-[22px] font-bold tracking-tight sm:text-3xl">
            【DEBUG】この画面は GrapeReverse.tsx です
          </h2>

          {/* 機種 */}
          <label className="block">
            <span className="block text-xs font-medium text-slate-700 sm:text-sm dark:text-slate-200">
              機種（プリセット）
            </span>
            <select
              value={machineKey}
              onChange={e => setMachineKey(e.target.value as MachineKey)}
              className="mt-1 h-14 w-full rounded-xl border border-slate-400 bg-white px-4 text-left text-xl tracking-wide tabular-nums focus:ring-blue-500 focus:outline-none sm:text-lg dark:border-slate-500 dark:bg-slate-700 dark:text-white"
            >
              {Object.entries(MACHINES).map(([key, v]) => (
                <option key={key} value={key}>
                  {v.label}
                </option>
              ))}
            </select>
          </label>

          {/* 入力フォーム */}
          <form className="grid grid-cols-2 gap-3">
            <Field label="BIG回数" value={bigCount} onChange={setBigCount} />
            <Field label="REG回数" value={regCount} onChange={setRegCount} />
            <Field
              label="差枚数（±）"
              value={diffCoins}
              onChange={setDiffCoins}
              placeholder="例: 500 / -300"
            />
            <Field label="総回転数" value={totalGames} onChange={setTotalGames} placeholder="G数" />
          </form>

          {/* 結果（選択機種） */}
          <div className="mt-1.5 grid grid-cols-2 gap-2.5 sm:gap-3">
            <ResultCard title="チェリー狙い" res={resAim} color="emerald" />
            <ResultCard title="フリー打ち" res={resFree} color="blue" />
          </div>
          <button
            type="button"
            onClick={() => {
              setBigCount('')
              setRegCount('')
              setDiffCoins('')
              setTotalGames('')
              localStorage.removeItem('grape-reverse-form')
            }}
            className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-rose-500 bg-rose-500/90 text-sm font-semibold tracking-wide text-white shadow-md hover:bg-rose-500 focus:ring-2 focus:ring-rose-500/70 focus:outline-none active:scale-[0.98] dark:border-rose-300 dark:bg-rose-400/90 dark:text-slate-900 dark:hover:bg-rose-300"
          >
            <span className="inline-block scale-125 text-3xl leading-none font-extrabold sm:scale-110 sm:text-2xl">
              ↺
            </span>
            <span>入力をすべてリセット</span>
          </button>
        </div>
        
        {/* ぶどう逆算の簡易評価カード */}
        {grapeEval && <GrapeEvalCard eval={grapeEval} />}
        
        {ready && (
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">
            <span className="inline-flex items-center gap-1">
              <span className="text-xs">▼</span>
              <span>下に設定別ボーナス＆ぶどう確率の一覧があります</span>
            </span>
          </div>
        )}
        {/* 機種別：設定ごとのボーナス＆ぶどう確率（分母） */}
        <GrapeTable
          machineKey={machineKey}
          highlightBig={highlightBigSetting}
          highlightReg={highlightRegSetting}
          highlightCombined={highlightCombinedSetting}
          highlightGrape={highlightGrapeSetting}
        />
        {/* ---- 注意書き（ミスタージャグラー以外） ---- */}
        {machineKey !== 'mister' && (
          <div className="mt-6 w-full max-w-md text-center text-[11px] text-slate-500 dark:text-slate-400">
            ※計算前提：チェリーは設定3の確率を使用。フリー打ちは奪取率66.7%（2/3）、ベル／ピエロは非奪取として無視。
          </div>
        )}
      </div>
    </div>
  )
}

/* ---- 入力フィールド（Enterで次へ） ---- */
function Field({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  placeholder?: string
}) {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      const form = e.currentTarget.form
      if (!form) return
      const elements = Array.from(form.elements).filter(
        (el): el is HTMLElement => el instanceof HTMLElement && el.tagName === 'INPUT',
      )
      const index = elements.indexOf(e.currentTarget)
      if (index >= 0 && index < elements.length - 1) elements[index + 1].focus()
    }
  }
  return (
    <label className="block space-y-0.5">
      <span className="block text-[15px] font-semibold text-slate-700 dark:text-slate-200">
        {label}
      </span>
      <input
        type="number"
        inputMode="numeric"
        step="1"
        value={value}
        onChange={e => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        className="mt-0.5 h-10 w-full rounded-xl border border-slate-400 bg-white px-3 text-left text-lg tracking-wide tabular-nums focus:ring-blue-500 focus:outline-none sm:text-base dark:border-slate-500 dark:bg-slate-700 dark:text-white"
      />
    </label>
  )
}

/* ---- 結果カード ---- */
function ResultCard({
  title,
  res,
  color,
}: {
  title: string
  res: CalcResult
  color: 'emerald' | 'blue'
}) {
  const theme =
    color === 'emerald'
      ? {
          border: 'border-emerald-200 dark:border-emerald-800',
          bg: 'bg-emerald-50/70 dark:bg-emerald-900/30',
          title: 'text-emerald-700 dark:text-emerald-300',
          num: 'text-emerald-700 dark:text-emerald-200',
          badgeBg: 'bg-emerald-100/80 dark:bg-emerald-800/70',
        }
      : {
          border: 'border-blue-200 dark:border-blue-800',
          bg: 'bg-blue-50/70 dark:bg-blue-900/30',
          title: 'text-blue-700 dark:text-blue-300',
          num: 'text-blue-700 dark:text-blue-200',
          badgeBg: 'bg-blue-100/80 dark:bg-blue-800/70',
        }

  return (
    <div className={`rounded-2xl border ${theme.border} ${theme.bg} px-4 py-3 sm:px-5 sm:py-4`}>
      {/* タイトル行 */}
      <div className="mb-2 flex items-center justify-center gap-2 sm:mb-3">
        <div
          className={`rounded-full px-3 py-1 text-xs font-semibold tracking-wide sm:text-[13px] ${theme.badgeBg}`}
        >
          {title}
        </div>
      </div>

      {res.ok ? (
        <div className="mt-2 space-y-2 text-center sm:mt-3">
          <div
            className={`text-3xl font-extrabold tracking-tight tabular-nums sm:text-[28px] ${theme.num}`}
          >
            1 / {nf2.format(res.denom)}
          </div>

          {/* 
  ↓↓↓ 必要になったらすぐ戻せるように、このまま残して非表示化しています ↓↓↓

<div className="mt-3 grid grid-cols-2 gap-2 sm:gap-3">
  <div className="rounded-xl bg-white/85 p-3 dark:bg-slate-800/80">
    <div className="text-[11px] text-slate-500 dark:text-slate-400 sm:text-[12px]">
      確率 p
    </div>
    <div className="mt-1 text-lg font-semibold tabular-nums sm:text-xl">
      {nf4.format(res.p)}
    </div>
  </div>
  <div className="rounded-xl bg-white/85 p-3 dark:bg-slate-800/80">
    <div className="text-[11px] text-slate-500 dark:text-slate-400 sm:text-[12px]">
      割合 %
    </div>
    <div className="mt-1 text-lg font-semibold tabular-nums sm:text-xl">
      {nf2.format(res.percent)}%
    </div>
  </div>
</div>

*/}
        </div>
      ) : (
  <p className="mt-3 text-center text-[12px] text-slate-500 sm:text-sm dark:text-slate-400">
    {res.reason === 'not_ready' ? (
      <>BIG / REG / 差枚 / 総回転数を入力すると自動で表示します。</>
    ) : res.reason === 'no_grape' ? (
      <>ぶどう分の払い出しが0以下になりました（差枚の符号や入力値の整合性を確認してください）。</>
    ) : res.reason === 'grape_error' ? (
      <>ぶどう回数の算出に失敗しました（入力値の整合性を確認してください）。</>
    ) : (
      <>計算できませんでした（入力値を確認してください）。</>
    )}
  </p>
)
}
    </div>
  )
}

/** 分母に最も近い設定番号を求める */
function findNearestSetting(target: number, table: { [key: number]: number }) {
  let nearest = 1
  let minDiff = Math.abs(table[1] - target)

  for (let s = 2; s <= 6; s++) {
    const diff = Math.abs(table[s] - target)
    if (diff < minDiff) {
      minDiff = diff
      nearest = s
    }
  }

  return nearest
}

/* ---- ぶどう＋ボーナス確率テーブル（設定別・分母） ---- */
function GrapeTable({
  machineKey,
  highlightBig,
  highlightReg,
  highlightCombined,
  highlightGrape,
}: {
  machineKey: MachineKey
  highlightBig: number | null
  highlightReg: number | null
  highlightCombined: number | null
  highlightGrape: number | null
}) {
  const grapeData = GRAPE_RATE_TABLE[machineKey]
  const bonusData = BONUS_RATE_TABLE[machineKey]

  // どちらかでもデータがなければ何も出さない
  if (!grapeData || !bonusData) return null

  const rows: { s: Setting; grape: number; big: number; reg: number; combined: number }[] = [
    {
      s: 1,
      grape: grapeData[1],
      big: bonusData[1].big,
      reg: bonusData[1].reg,
      combined: bonusData[1].combined,
    },
    {
      s: 2,
      grape: grapeData[2],
      big: bonusData[2].big,
      reg: bonusData[2].reg,
      combined: bonusData[2].combined,
    },
    {
      s: 3,
      grape: grapeData[3],
      big: bonusData[3].big,
      reg: bonusData[3].reg,
      combined: bonusData[3].combined,
    },
    {
      s: 4,
      grape: grapeData[4],
      big: bonusData[4].big,
      reg: bonusData[4].reg,
      combined: bonusData[4].combined,
    },
    {
      s: 5,
      grape: grapeData[5],
      big: bonusData[5].big,
      reg: bonusData[5].reg,
      combined: bonusData[5].combined,
    },
    {
      s: 6,
      grape: grapeData[6],
      big: bonusData[6].big,
      reg: bonusData[6].reg,
      combined: bonusData[6].combined,
    },
  ]

  return (
    <div className="mt-4 w-full max-w-md sm:mt-2 sm:max-w-lg">
      <div className="overflow-hidden rounded-2xl shadow ring-1 ring-slate-300 dark:ring-slate-800">
        <div className="bg-white px-4 py-3 dark:bg-slate-900">
          <h3 className="text-sm font-semibold sm:text-base">
            {MACHINES[machineKey].label}：設定別 ボーナス＆ぶどう確率
          </h3>
        </div>
        <div className="overflow-x-auto bg-white dark:bg-slate-900">
          <table className="min-w-full text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-600 dark:bg-slate-800/50 dark:text-slate-300">
              <tr>
                <th className="w-14 px-3 py-2 text-left whitespace-nowrap sm:w-16 sm:px-4">設定</th>
                <th className="px-3 py-2 text-left whitespace-nowrap sm:px-4">B確率</th>
                <th className="px-3 py-2 text-left whitespace-nowrap sm:px-4">R確率</th>
                <th className="px-3 py-2 text-left whitespace-nowrap sm:px-4">合成</th>
                <th className="px-3 py-2 text-left whitespace-nowrap sm:px-4">ぶ確率</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {rows.map(r => {
                const isBigHit = highlightBig === r.s
                const isRegHit = highlightReg === r.s
                const isCombinedHit = highlightCombined === r.s
                const isGrapeHit = highlightGrape === r.s

                const clsBig = isBigHit ? 'font-extrabold text-blue-900 bg-blue-200/60 dark:text-blue-100 dark:bg-blue-800/60' : ''
                const clsReg = isRegHit ? 'font-extrabold text-rose-900 bg-rose-200/60 dark:text-rose-100 dark:bg-rose-800/60' : ''
                const clsCombined = isCombinedHit
                  ? 'font-extrabold text-purple-900 bg-purple-200/60 dark:text-purple-100 dark:bg-purple-800/60'
                  : ''
                const clsGrape = isGrapeHit
                  ? 'font-extrabold text-emerald-900 bg-emerald-200/60 dark:text-emerald-100 dark:bg-emerald-800/60'
                  : ''

                return (
                  <tr key={r.s}>
                    <td className="px-4 py-2">{r.s}</td>

                    <td className={`px-4 py-2 tabular-nums ${clsBig}`}>1/{nf1.format(r.big)}</td>
                    <td className={`px-4 py-2 tabular-nums ${clsReg}`}>1/{nf1.format(r.reg)}</td>
                    <td className={`px-4 py-2 tabular-nums ${clsCombined}`}>
                      1/{nf1.format(r.combined)}
                    </td>
                    <td className={`px-4 py-2 tabular-nums ${clsGrape}`}>
                      1/{nf2.format(r.grape)}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

/* ---- ぶどう評価カード ---- */
function GrapeEvalCard({ eval: e }: { eval: GrapeEval }) {
  const diffLabel =
    e.diff < 0
      ? '公称値よりぶどう良好'
      : e.diff > 0
        ? '公称値よりぶどうやや弱め'
        : '公称値とほぼ一致'

  const confidenceLabel =
    e.confidence === 'high' ? '信頼度：高' : e.confidence === 'mid' ? '信頼度：中' : '信頼度：低'

  return (
    <div className="mt-3 w-full max-w-md sm:mt-3 sm:max-w-lg">
      <div className="rounded-2xl border border-amber-200 bg-amber-50/80 px-4 py-3 text-xs shadow-sm sm:text-sm dark:border-amber-700 dark:bg-amber-900/30">
        <div className="mb-1 flex items-center justify-between gap-2">
          <span className="font-semibold text-amber-900 dark:text-amber-100">
            ぶどう推定の簡易評価（チェリー狙い）
          </span>
          <span className="text-[11px] text-amber-800/80 dark:text-amber-200/80">
            {confidenceLabel}
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <div className="text-[11px] text-slate-600 dark:text-slate-300">逆算ぶどう</div>
            <div className="text-sm font-semibold tabular-nums dark:text-slate-50">
              1/{nf2.format(e.actualDenom)}
            </div>
          </div>
          <div>
            <div className="text-[11px] text-slate-600 dark:text-slate-300">
              最も近い設定（公称値）
            </div>
            <div className="text-sm font-semibold tabular-nums dark:text-slate-50">
              設定{e.nearestSetting}：1/{nf2.format(e.nearestSettingDenom)}
            </div>
          </div>
        </div>
        <div className="mt-1 flex flex-wrap items-baseline justify-between gap-2">
          <div className="text-[11px] text-slate-700 dark:text-slate-200">
            差分：{e.diff >= 0 ? '+' : ''}
            {nf2.format(e.diff)}（{diffLabel}）
          </div>
          <div className="text-[11px] text-slate-600 dark:text-slate-300">
            総回転数：{e.totalGames.toLocaleString('ja-JP')}G
          </div>
        </div>
      </div>
    </div>
  )
}
